﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;
using System.Data.SqlClient;

namespace Population_manager
{
    public partial class Places : Form
    {
        SqlConnection connection;
        string connectionString;
        
        public Places()
        {
            InitializeComponent();

            connectionString = ConfigurationManager.ConnectionStrings["Population_manager.Properties.Settings.PMDBConnectionString"].ConnectionString;
        }

        //This code accepts data inputted by the customer, verifies it and inserts it into the "Places" table of the database
        private void button1_Click(object sender, EventArgs e)
        {
            string query = "INSERT INTO Places VALUES (@Place_Name, @Place_Capacity, @Place_Type)";

            using (connection = new SqlConnection(connectionString))
            using (SqlCommand command = new SqlCommand(query, connection))
            {
                connection.Open();
                
                command.Parameters.AddWithValue("@Place_Name", PNameTxt.Text);
                command.Parameters.AddWithValue("@Place_Type", PTypeCombo.Text);
                command.Parameters.AddWithValue("@Place_Capacity", CapTxt.Text);

                if (CheckInput() == true)
                {
                    command.ExecuteScalar();
                }
            }

            CreatePlace();
        }

        //This code verifies that any data inputted by the user is of the correct data type and not null (where necessary)
        private bool CheckInput()
        {
            string Pname = PNameTxt.Text;

            for (int i = 0; i < Pname.Length; i++)
            {
                if (char.IsDigit(Pname[i]))
                {
                    MessageBox.Show("ERROR: Not all data is valid");
                    return false;
                }
            }

            string Cap = CapTxt.Text;

            for (int i = 0; i < Cap.Length; i++)
            {
                if (!char.IsDigit(Cap[i]))
                {
                    MessageBox.Show("ERROR: Not all data is valid");
                    return false;
                }
            }

            string Ptype = PTypeCombo.Text;

            if (Pname == "" || Cap == "" || Ptype  == "")
            {
                MessageBox.Show("ERROR: All input fields must contain data");
                return false;
            }

            return true;
        }

        //This code selects data from the "Places" table of the database and uses it to populate a number of the page's listboxes
        private void CreatePlace()
        {
            using (connection = new SqlConnection(connectionString))
            using (SqlDataAdapter adapter = new SqlDataAdapter("SELECT * FROM Places", connection))
            {
                DataTable Places = new DataTable();
                adapter.Fill(Places);

                PNameList.DisplayMember = "Place_Name";
                PNameList.ValueMember = "Id";

                PTypeList.DisplayMember = "Place_Type";
                PTypeList.ValueMember = "Id";

                PCapList.DisplayMember = "Place_Capacity";
                PCapList.ValueMember = "Id";

                PNameList.DataSource = Places;
                PTypeList.DataSource = Places;
                PCapList.DataSource = Places;
            }
        }

        private void Places_Load(object sender, EventArgs e)
        {
            CreatePlace();
        }

        //This code selects data from the "Plaecs" table of the database and uses it to populate a number of the page's listboxes
        private void ShowPopulation()
        {
            String query  = "SELECT FName + ' ' + LName AS FullName FROM People WHERE PlaceID = @PlaceID";
            
            using (connection = new SqlConnection(connectionString))
            using (SqlCommand command = new SqlCommand(query, connection))
            using (SqlDataAdapter adapter = new SqlDataAdapter(command))
            {
                command.Parameters.AddWithValue("@PlaceID", PNameList.SelectedValue);

                DataTable people = new DataTable();
                adapter.Fill(people);

                PopList.DisplayMember = "FullName";
                PopList.ValueMember = "Id";
                PopList.DataSource = people;
            }
        }

        private void PNameList_SelectedIndexChanged(object sender, EventArgs e)
        {
            ShowPopulation();
        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}