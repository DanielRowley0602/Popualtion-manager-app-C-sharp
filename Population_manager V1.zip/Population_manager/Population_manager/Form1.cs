﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Population_manager
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        //This button will open the "menu_page" form
        private void Start_Click(object sender, EventArgs e)
        {
            Menu menu_page = new Menu();
            menu_page.Show();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
