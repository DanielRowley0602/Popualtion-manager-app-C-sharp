﻿
namespace Population_manager
{
    partial class People
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.AddBtn = new System.Windows.Forms.Button();
            this.FNameTxt = new System.Windows.Forms.TextBox();
            this.AgeTxt = new System.Windows.Forms.TextBox();
            this.LNameTxt = new System.Windows.Forms.TextBox();
            this.OccupationTxt = new System.Windows.Forms.TextBox();
            this.peopleBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.pMDBDataSet = new Population_manager.PMDBDataSet();
            this.peopleTableAdapter = new Population_manager.PMDBDataSetTableAdapters.PeopleTableAdapter();
            this.pmdbDataSet1 = new Population_manager.PMDBDataSet();
            this.NameList = new System.Windows.Forms.ListBox();
            this.TitleList = new System.Windows.Forms.ListBox();
            this.AgeList = new System.Windows.Forms.ListBox();
            this.StandList = new System.Windows.Forms.ListBox();
            this.OccList = new System.Windows.Forms.ListBox();
            this.PNameList = new System.Windows.Forms.ListBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.StandingCombo = new System.Windows.Forms.ComboBox();
            this.peopleBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.pMDBDataSet3 = new Population_manager.PMDBDataSet3();
            this.placesBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.pMDBDataSet2 = new Population_manager.PMDBDataSet2();
            this.pMDBDataSet11 = new Population_manager.PMDBDataSet1();
            this.placesBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.placesTableAdapter = new Population_manager.PMDBDataSet1TableAdapters.PlacesTableAdapter();
            this.placesTableAdapter1 = new Population_manager.PMDBDataSet2TableAdapters.PlacesTableAdapter();
            this.peopleTableAdapter1 = new Population_manager.PMDBDataSet3TableAdapters.PeopleTableAdapter();
            this.LocCombo = new System.Windows.Forms.ComboBox();
            this.placesBindingSource2 = new System.Windows.Forms.BindingSource(this.components);
            this.pMDBDataSet4 = new Population_manager.PMDBDataSet4();
            this.label13 = new System.Windows.Forms.Label();
            this.TitleCombo = new System.Windows.Forms.ComboBox();
            this.placesTableAdapter2 = new Population_manager.PMDBDataSet4TableAdapters.PlacesTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.peopleBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pMDBDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pmdbDataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.peopleBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pMDBDataSet3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.placesBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pMDBDataSet2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pMDBDataSet11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.placesBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.placesBindingSource2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pMDBDataSet4)).BeginInit();
            this.SuspendLayout();
            // 
            // AddBtn
            // 
            this.AddBtn.Location = new System.Drawing.Point(352, 371);
            this.AddBtn.Name = "AddBtn";
            this.AddBtn.Size = new System.Drawing.Size(75, 23);
            this.AddBtn.TabIndex = 0;
            this.AddBtn.Text = "Add";
            this.AddBtn.UseVisualStyleBackColor = true;
            this.AddBtn.Click += new System.EventHandler(this.AddBtn_Click);
            // 
            // FNameTxt
            // 
            this.FNameTxt.Location = new System.Drawing.Point(339, 213);
            this.FNameTxt.Name = "FNameTxt";
            this.FNameTxt.Size = new System.Drawing.Size(100, 20);
            this.FNameTxt.TabIndex = 1;
            // 
            // AgeTxt
            // 
            this.AgeTxt.Location = new System.Drawing.Point(339, 265);
            this.AgeTxt.Name = "AgeTxt";
            this.AgeTxt.Size = new System.Drawing.Size(100, 20);
            this.AgeTxt.TabIndex = 2;
            // 
            // LNameTxt
            // 
            this.LNameTxt.Location = new System.Drawing.Point(339, 239);
            this.LNameTxt.Name = "LNameTxt";
            this.LNameTxt.Size = new System.Drawing.Size(100, 20);
            this.LNameTxt.TabIndex = 3;
            // 
            // OccupationTxt
            // 
            this.OccupationTxt.Location = new System.Drawing.Point(339, 318);
            this.OccupationTxt.Name = "OccupationTxt";
            this.OccupationTxt.Size = new System.Drawing.Size(100, 20);
            this.OccupationTxt.TabIndex = 4;
            // 
            // peopleBindingSource
            // 
            this.peopleBindingSource.DataMember = "People";
            this.peopleBindingSource.DataSource = this.pMDBDataSet;
            // 
            // pMDBDataSet
            // 
            this.pMDBDataSet.DataSetName = "PMDBDataSet";
            this.pMDBDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // peopleTableAdapter
            // 
            this.peopleTableAdapter.ClearBeforeFill = true;
            // 
            // pmdbDataSet1
            // 
            this.pmdbDataSet1.DataSetName = "PMDBDataSet";
            this.pmdbDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // NameList
            // 
            this.NameList.FormattingEnabled = true;
            this.NameList.Location = new System.Drawing.Point(138, 50);
            this.NameList.Name = "NameList";
            this.NameList.Size = new System.Drawing.Size(120, 95);
            this.NameList.TabIndex = 7;
            this.NameList.SelectedIndexChanged += new System.EventHandler(this.listBox1_SelectedIndexChanged);
            // 
            // TitleList
            // 
            this.TitleList.FormattingEnabled = true;
            this.TitleList.Location = new System.Drawing.Point(12, 50);
            this.TitleList.Name = "TitleList";
            this.TitleList.Size = new System.Drawing.Size(120, 95);
            this.TitleList.TabIndex = 8;
            // 
            // AgeList
            // 
            this.AgeList.FormattingEnabled = true;
            this.AgeList.Location = new System.Drawing.Point(264, 50);
            this.AgeList.Name = "AgeList";
            this.AgeList.Size = new System.Drawing.Size(120, 95);
            this.AgeList.TabIndex = 9;
            // 
            // StandList
            // 
            this.StandList.FormattingEnabled = true;
            this.StandList.Location = new System.Drawing.Point(390, 50);
            this.StandList.Name = "StandList";
            this.StandList.Size = new System.Drawing.Size(120, 95);
            this.StandList.TabIndex = 10;
            // 
            // OccList
            // 
            this.OccList.FormattingEnabled = true;
            this.OccList.Location = new System.Drawing.Point(516, 50);
            this.OccList.Name = "OccList";
            this.OccList.Size = new System.Drawing.Size(120, 95);
            this.OccList.TabIndex = 11;
            // 
            // PNameList
            // 
            this.PNameList.FormattingEnabled = true;
            this.PNameList.Location = new System.Drawing.Point(642, 50);
            this.PNameList.Name = "PNameList";
            this.PNameList.Size = new System.Drawing.Size(120, 95);
            this.PNameList.TabIndex = 12;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(138, 34);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(35, 13);
            this.label1.TabIndex = 13;
            this.label1.Text = "Name";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 34);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(27, 13);
            this.label2.TabIndex = 14;
            this.label2.Text = "Title";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(264, 34);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(26, 13);
            this.label3.TabIndex = 15;
            this.label3.Text = "Age";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(642, 34);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(48, 13);
            this.label4.TabIndex = 16;
            this.label4.Text = "Location";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(516, 34);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(62, 13);
            this.label5.TabIndex = 17;
            this.label5.Text = "Occupation";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(390, 34);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(49, 13);
            this.label6.TabIndex = 18;
            this.label6.Text = "Standing";
            this.label6.Click += new System.EventHandler(this.label6_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(271, 321);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(62, 13);
            this.label7.TabIndex = 19;
            this.label7.Text = "Occupation";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(284, 294);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(49, 13);
            this.label8.TabIndex = 20;
            this.label8.Text = "Standing";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(307, 268);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(26, 13);
            this.label9.TabIndex = 21;
            this.label9.Text = "Age";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(280, 242);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(53, 13);
            this.label10.TabIndex = 22;
            this.label10.Text = "Lastname";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(281, 216);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(52, 13);
            this.label11.TabIndex = 23;
            this.label11.Text = "Firstname";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(285, 347);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(48, 13);
            this.label12.TabIndex = 24;
            this.label12.Text = "Location";
            // 
            // StandingCombo
            // 
            this.StandingCombo.DataBindings.Add(new System.Windows.Forms.Binding("SelectedValue", this.peopleBindingSource1, "Standing", true));
            this.StandingCombo.FormattingEnabled = true;
            this.StandingCombo.Items.AddRange(new object[] {
            "Monarch",
            "Royality",
            "Noble",
            "Upper class",
            "Middle class",
            "Working class",
            "Lower class"});
            this.StandingCombo.Location = new System.Drawing.Point(339, 291);
            this.StandingCombo.Name = "StandingCombo";
            this.StandingCombo.Size = new System.Drawing.Size(100, 21);
            this.StandingCombo.TabIndex = 25;
            // 
            // peopleBindingSource1
            // 
            this.peopleBindingSource1.DataMember = "People";
            this.peopleBindingSource1.DataSource = this.pMDBDataSet3;
            // 
            // pMDBDataSet3
            // 
            this.pMDBDataSet3.DataSetName = "PMDBDataSet3";
            this.pMDBDataSet3.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // placesBindingSource1
            // 
            this.placesBindingSource1.DataMember = "Places";
            this.placesBindingSource1.DataSource = this.pMDBDataSet2;
            // 
            // pMDBDataSet2
            // 
            this.pMDBDataSet2.DataSetName = "PMDBDataSet2";
            this.pMDBDataSet2.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // pMDBDataSet11
            // 
            this.pMDBDataSet11.DataSetName = "PMDBDataSet1";
            this.pMDBDataSet11.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // placesBindingSource
            // 
            this.placesBindingSource.DataMember = "Places";
            this.placesBindingSource.DataSource = this.pMDBDataSet11;
            // 
            // placesTableAdapter
            // 
            this.placesTableAdapter.ClearBeforeFill = true;
            // 
            // placesTableAdapter1
            // 
            this.placesTableAdapter1.ClearBeforeFill = true;
            // 
            // peopleTableAdapter1
            // 
            this.peopleTableAdapter1.ClearBeforeFill = true;
            // 
            // LocCombo
            // 
            this.LocCombo.DataSource = this.placesBindingSource2;
            this.LocCombo.DisplayMember = "Place_Name";
            this.LocCombo.FormattingEnabled = true;
            this.LocCombo.Location = new System.Drawing.Point(339, 344);
            this.LocCombo.Name = "LocCombo";
            this.LocCombo.Size = new System.Drawing.Size(100, 21);
            this.LocCombo.TabIndex = 27;
            this.LocCombo.ValueMember = "Place_Name";
            // 
            // placesBindingSource2
            // 
            this.placesBindingSource2.DataMember = "Places";
            this.placesBindingSource2.DataSource = this.pMDBDataSet4;
            // 
            // pMDBDataSet4
            // 
            this.pMDBDataSet4.DataSetName = "PMDBDataSet4";
            this.pMDBDataSet4.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(306, 190);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(27, 13);
            this.label13.TabIndex = 29;
            this.label13.Text = "Title";
            // 
            // TitleCombo
            // 
            this.TitleCombo.FormattingEnabled = true;
            this.TitleCombo.Items.AddRange(new object[] {
            "King",
            "Queen",
            "Prince",
            "Princess",
            "Lord",
            "Lady",
            "Sir",
            "MR",
            "Miss"});
            this.TitleCombo.Location = new System.Drawing.Point(339, 186);
            this.TitleCombo.Name = "TitleCombo";
            this.TitleCombo.Size = new System.Drawing.Size(100, 21);
            this.TitleCombo.TabIndex = 30;
            // 
            // placesTableAdapter2
            // 
            this.placesTableAdapter2.ClearBeforeFill = true;
            // 
            // People
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(776, 404);
            this.Controls.Add(this.TitleCombo);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.LocCombo);
            this.Controls.Add(this.StandingCombo);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.PNameList);
            this.Controls.Add(this.OccList);
            this.Controls.Add(this.StandList);
            this.Controls.Add(this.AgeList);
            this.Controls.Add(this.TitleList);
            this.Controls.Add(this.NameList);
            this.Controls.Add(this.OccupationTxt);
            this.Controls.Add(this.LNameTxt);
            this.Controls.Add(this.AgeTxt);
            this.Controls.Add(this.FNameTxt);
            this.Controls.Add(this.AddBtn);
            this.Name = "People";
            this.Text = "People";
            this.Load += new System.EventHandler(this.People_Load);
            ((System.ComponentModel.ISupportInitialize)(this.peopleBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pMDBDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pmdbDataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.peopleBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pMDBDataSet3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.placesBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pMDBDataSet2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pMDBDataSet11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.placesBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.placesBindingSource2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pMDBDataSet4)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button AddBtn;
        private System.Windows.Forms.TextBox FNameTxt;
        private System.Windows.Forms.TextBox AgeTxt;
        private System.Windows.Forms.TextBox LNameTxt;
        private System.Windows.Forms.TextBox OccupationTxt;
        private PMDBDataSet pMDBDataSet;
        private System.Windows.Forms.BindingSource peopleBindingSource;
        private PMDBDataSetTableAdapters.PeopleTableAdapter peopleTableAdapter;
        private PMDBDataSet pmdbDataSet1;
        private System.Windows.Forms.ListBox NameList;
        private System.Windows.Forms.ListBox TitleList;
        private System.Windows.Forms.ListBox AgeList;
        private System.Windows.Forms.ListBox StandList;
        private System.Windows.Forms.ListBox OccList;
        private System.Windows.Forms.ListBox PNameList;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.ComboBox StandingCombo;
        private PMDBDataSet1 pMDBDataSet11;
        private System.Windows.Forms.BindingSource placesBindingSource;
        private PMDBDataSet1TableAdapters.PlacesTableAdapter placesTableAdapter;
        private PMDBDataSet2 pMDBDataSet2;
        private System.Windows.Forms.BindingSource placesBindingSource1;
        private PMDBDataSet2TableAdapters.PlacesTableAdapter placesTableAdapter1;
        private PMDBDataSet3 pMDBDataSet3;
        private System.Windows.Forms.BindingSource peopleBindingSource1;
        private PMDBDataSet3TableAdapters.PeopleTableAdapter peopleTableAdapter1;
        private System.Windows.Forms.ComboBox LocCombo;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.ComboBox TitleCombo;
        private PMDBDataSet4 pMDBDataSet4;
        private System.Windows.Forms.BindingSource placesBindingSource2;
        private PMDBDataSet4TableAdapters.PlacesTableAdapter placesTableAdapter2;
    }
}