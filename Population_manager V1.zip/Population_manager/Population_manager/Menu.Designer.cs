﻿
namespace Population_manager
{
    partial class Menu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.PeopleBtn = new System.Windows.Forms.Button();
            this.PlacesBtn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // PeopleBtn
            // 
            this.PeopleBtn.Location = new System.Drawing.Point(22, 12);
            this.PeopleBtn.Name = "PeopleBtn";
            this.PeopleBtn.Size = new System.Drawing.Size(75, 23);
            this.PeopleBtn.TabIndex = 0;
            this.PeopleBtn.Text = "People";
            this.PeopleBtn.UseVisualStyleBackColor = true;
            this.PeopleBtn.Click += new System.EventHandler(this.PeopleBtn_Click);
            // 
            // PlacesBtn
            // 
            this.PlacesBtn.Location = new System.Drawing.Point(22, 41);
            this.PlacesBtn.Name = "PlacesBtn";
            this.PlacesBtn.Size = new System.Drawing.Size(75, 23);
            this.PlacesBtn.TabIndex = 1;
            this.PlacesBtn.Text = "Places";
            this.PlacesBtn.UseVisualStyleBackColor = true;
            this.PlacesBtn.Click += new System.EventHandler(this.PlacesBtn_Click_1);
            // 
            // Menu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(120, 167);
            this.Controls.Add(this.PlacesBtn);
            this.Controls.Add(this.PeopleBtn);
            this.Name = "Menu";
            this.Text = "Menu";
            this.Load += new System.EventHandler(this.Menu_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button PeopleBtn;
        private System.Windows.Forms.Button PlacesBtn;
    }
}