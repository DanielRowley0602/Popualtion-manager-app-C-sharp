﻿
namespace Population_manager
{
    partial class Places
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.PNameList = new System.Windows.Forms.ListBox();
            this.PTypeList = new System.Windows.Forms.ListBox();
            this.PNameTxt = new System.Windows.Forms.TextBox();
            this.AddBtn = new System.Windows.Forms.Button();
            this.CapTxt = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.PCapList = new System.Windows.Forms.ListBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.PTypeCombo = new System.Windows.Forms.ComboBox();
            this.PopList = new System.Windows.Forms.ListBox();
            this.label7 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // PNameList
            // 
            this.PNameList.FormattingEnabled = true;
            this.PNameList.Location = new System.Drawing.Point(12, 38);
            this.PNameList.Name = "PNameList";
            this.PNameList.Size = new System.Drawing.Size(120, 95);
            this.PNameList.TabIndex = 0;
            this.PNameList.SelectedIndexChanged += new System.EventHandler(this.PNameList_SelectedIndexChanged);
            // 
            // PTypeList
            // 
            this.PTypeList.FormattingEnabled = true;
            this.PTypeList.Location = new System.Drawing.Point(138, 38);
            this.PTypeList.Name = "PTypeList";
            this.PTypeList.Size = new System.Drawing.Size(120, 95);
            this.PTypeList.TabIndex = 1;
            // 
            // PNameTxt
            // 
            this.PNameTxt.Location = new System.Drawing.Point(209, 155);
            this.PNameTxt.Name = "PNameTxt";
            this.PNameTxt.Size = new System.Drawing.Size(100, 20);
            this.PNameTxt.TabIndex = 2;
            // 
            // AddBtn
            // 
            this.AddBtn.Location = new System.Drawing.Point(222, 233);
            this.AddBtn.Name = "AddBtn";
            this.AddBtn.Size = new System.Drawing.Size(75, 23);
            this.AddBtn.TabIndex = 4;
            this.AddBtn.Text = "Add";
            this.AddBtn.UseVisualStyleBackColor = true;
            this.AddBtn.Click += new System.EventHandler(this.button1_Click);
            // 
            // CapTxt
            // 
            this.CapTxt.Location = new System.Drawing.Point(209, 207);
            this.CapTxt.Name = "CapTxt";
            this.CapTxt.Size = new System.Drawing.Size(100, 20);
            this.CapTxt.TabIndex = 5;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(138, 158);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(65, 13);
            this.label1.TabIndex = 6;
            this.label1.Text = "Place Name";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(155, 210);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(48, 13);
            this.label2.TabIndex = 7;
            this.label2.Text = "Capacity";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(142, 184);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(61, 13);
            this.label3.TabIndex = 8;
            this.label3.Text = "Place Type";
            // 
            // PCapList
            // 
            this.PCapList.FormattingEnabled = true;
            this.PCapList.Location = new System.Drawing.Point(264, 38);
            this.PCapList.Name = "PCapList";
            this.PCapList.Size = new System.Drawing.Size(120, 95);
            this.PCapList.TabIndex = 9;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(9, 22);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(65, 13);
            this.label4.TabIndex = 10;
            this.label4.Text = "Place Name";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(135, 22);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(61, 13);
            this.label5.TabIndex = 11;
            this.label5.Text = "Place Type";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(261, 22);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(48, 13);
            this.label6.TabIndex = 12;
            this.label6.Text = "Capacity";
            // 
            // PTypeCombo
            // 
            this.PTypeCombo.FormattingEnabled = true;
            this.PTypeCombo.Items.AddRange(new object[] {
            "Grand city",
            "City",
            "Village",
            "Fortress"});
            this.PTypeCombo.Location = new System.Drawing.Point(209, 180);
            this.PTypeCombo.Name = "PTypeCombo";
            this.PTypeCombo.Size = new System.Drawing.Size(100, 21);
            this.PTypeCombo.TabIndex = 13;
            // 
            // PopList
            // 
            this.PopList.FormattingEnabled = true;
            this.PopList.Location = new System.Drawing.Point(390, 38);
            this.PopList.MultiColumn = true;
            this.PopList.Name = "PopList";
            this.PopList.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended;
            this.PopList.Size = new System.Drawing.Size(120, 95);
            this.PopList.TabIndex = 14;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(387, 22);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(51, 13);
            this.label7.TabIndex = 15;
            this.label7.Text = "Populous";
            // 
            // Places
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(522, 277);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.PopList);
            this.Controls.Add(this.PTypeCombo);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.PCapList);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.CapTxt);
            this.Controls.Add(this.AddBtn);
            this.Controls.Add(this.PNameTxt);
            this.Controls.Add(this.PTypeList);
            this.Controls.Add(this.PNameList);
            this.Name = "Places";
            this.Text = "Places";
            this.Load += new System.EventHandler(this.Places_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox PNameList;
        private System.Windows.Forms.ListBox PTypeList;
        private System.Windows.Forms.TextBox PNameTxt;
        private System.Windows.Forms.Button AddBtn;
        private System.Windows.Forms.TextBox CapTxt;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ListBox PCapList;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox PTypeCombo;
        private System.Windows.Forms.ListBox PopList;
        private System.Windows.Forms.Label label7;
    }
}