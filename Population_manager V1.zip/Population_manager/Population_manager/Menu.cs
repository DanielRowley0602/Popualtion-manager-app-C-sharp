﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Population_manager
{
    public partial class Menu : Form
    {
        public Menu()
        {
            InitializeComponent();
        }

        //This button will open the "people_page" form
        private void PeopleBtn_Click(object sender, EventArgs e)
        {
            People people_page = new People();
            people_page.Show();
        }

        //This button will open the "places_page" form
        private void PlacesBtn_Click_1(object sender, EventArgs e)
        {
            Places places_page = new Places();
            places_page.Show();
        }

        private void Menu_Load(object sender, EventArgs e)
        {

        }
    }
}
