﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;
using System.Data.SqlClient;

namespace Population_manager
{
	public partial class People : Form
	{
		SqlConnection connection;
		string connectionString;

		public People()
		{
			InitializeComponent();

			connectionString = ConfigurationManager.ConnectionStrings["Population_manager.Properties.Settings.PMDBConnectionString"].ConnectionString;
		}

		private void People_Load(object sender, EventArgs e)
		{
			CreatePeople();

			Populatecity();
		}

		//This code selects data from the "People" table of the database and uses it to populate a number of the page's listboxes
		private void CreatePeople()
		{
			using (connection = new SqlConnection(connectionString))
			using (SqlDataAdapter adapter = new SqlDataAdapter("SELECT Id, PlaceID, Title, FName + ' ' + LName AS FullName, Age, Standing, Occupation FROM People", connection))
			{
				DataTable People = new DataTable();
				adapter.Fill(People);

				TitleList.DisplayMember = "Title";
				TitleList.ValueMember = "Id";

				NameList.DisplayMember = "FullName";
				NameList.ValueMember = "Id";

				AgeList.DisplayMember = "Age";
				AgeList.ValueMember = "Id";

				StandList.DisplayMember = "Standing";
				StandList.ValueMember = "Id";

				OccList.DisplayMember = "Occupation";
				OccList.ValueMember = "Id";

				NameList.DataSource = People;
				TitleList.DataSource = People;
				AgeList.DataSource = People;
				StandList.DataSource = People;
				OccList.DataSource = People;
				
			}
		}

		//This code takes a person's location as inputted by the user and it's ID and returns it
		private string PlaceID_Finder()
		{
			string query = "SELECT Id FROM Places WHERE Place_Name = @PlaceID";

			using (connection = new SqlConnection(connectionString))
			using (SqlCommand command = new SqlCommand(query, connection))
			{
				connection.Open();

				command.Parameters.AddWithValue("@PlaceID", LocCombo.Text);

				command.ExecuteScalar();

				SqlDataReader reader = command.ExecuteReader();
				while(reader.Read())
				{
					string id = reader["Id"].ToString();
					return id;
				}
				reader.Close();

				return null;
			}
		}
		
		//This code accepts data inputted by the customer, verifies it and inserts it into the "Poeple" table of the database
		private void AddBtn_Click(object sender, EventArgs e)
		{
			string query = "INSERT INTO People VALUES (@PlaceID, @Title, @FName, @LName, @Age, @Standing, @Occupation)";

			using (connection = new SqlConnection(connectionString))
			using (SqlCommand command = new SqlCommand(query, connection))
			{
				connection.Open();

				command.Parameters.AddWithValue("@PlaceID", PlaceID_Finder());
				command.Parameters.AddWithValue("@Title", TitleCombo.Text);
				command.Parameters.AddWithValue("@FName", FNameTxt.Text);
				command.Parameters.AddWithValue("@LName", LNameTxt.Text);
				command.Parameters.AddWithValue("@Age", AgeTxt.Text);
				command.Parameters.AddWithValue("@Standing", StandingCombo.Text);

				if (OccupationTxt.Text != "")
				{
					command.Parameters.AddWithValue("@Occupation", OccupationTxt.Text);
				}

				if (OccupationTxt.Text == "")
				{
					command.Parameters.AddWithValue("@Occupation", "N/A");
				}
				

				if (CheckInput() == true)
				{
					command.ExecuteScalar();
				}
				
			}

			CreatePeople();

			Populatecity();
		}

		//This code verifies that any data inputted by the user is of the correct data type and not null (where necessary)
		private bool CheckInput()
		{
			string Fname = FNameTxt.Text;

			for (int i = 0; i < Fname.Length; i++)
			{
				if (char.IsDigit(Fname[i]))
				{
					MessageBox.Show("ERROR: Not all data is valid");
					return false;
				}
			}

			string Lname = LNameTxt.Text;

			for (int i = 0; i < Lname.Length; i++)
			{
				if (char.IsDigit(Lname[i]))
				{
					MessageBox.Show("ERROR: Not all data is valid");
					return false;
				}
			}

			string Age = AgeTxt.Text;

			for (int i = 0; i < Age.Length; i++)
			{
				if (!char.IsDigit(Age[i]))
				{
					MessageBox.Show("ERROR: Not all data is valid");
					return false;
				}
			}

			string Occupation = OccupationTxt.Text;

			for (int i = 0; i < Occupation.Length; i++)
			{
				if (char.IsDigit(Occupation[i]))
				{
					MessageBox.Show("ERROR: Not all data is valid");
					return false;
				}
			}

			string Location = LocCombo.Text;
			string Title = TitleCombo.Text;
			string Standing = StandingCombo.Text;

			if (Location == "" || Title == "" || Fname == "" || Lname == "" || Age == "" || Standing == "")
			{
				MessageBox.Show("ERROR: All input fields must contain data");
				return false;
			}

			return true;
		}

		private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
		{

		}

		//This code selects data from the "Places" table of the database and uses it to populate the page's "Place name" listboxe
		private void Populatecity()
		{
			using (connection = new SqlConnection(connectionString))
			using (SqlDataAdapter adapter = new SqlDataAdapter("SELECT Places.Place_Name FROM Places " +
			"INNER JOIN People ON Places.Id = People.PlaceID", connection))
			{
				DataTable Places = new DataTable();
				adapter.Fill(Places);

				PNameList.DisplayMember = "Place_Name";
				PNameList.ValueMember = "Id";

				PNameList.DataSource = Places;
			}
		}

		private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
		{

		}

		private void label6_Click(object sender, EventArgs e)
		{

		}
	}
}
